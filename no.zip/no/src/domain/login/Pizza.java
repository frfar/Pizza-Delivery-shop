package domain.login;

public class Pizza {
	private int Pepperoni;
	private int veggie;
	private int margherita;
	public int getPepperoni() {
		return Pepperoni;
	}
	public void setPepp(int num) {
		this.Pepperoni = num;
	}
	public int getV() {
		return veggie;
	}
	public void setV(int num) {
		this.veggie = num;
	}
	public int getM() {
		return margherita;
	}
	public void setM(int num) {
		this.margherita = num;
	}

}
